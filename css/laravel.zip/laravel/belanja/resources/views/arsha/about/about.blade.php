@extends('arsha.layout.app')
{{-- orang tua dari setiap halaaman --}}

{{-- extend itu perintah agar kita dapat menggunakan 
    semua code yang ada di dalam file yang di extends--}}

    {{-- halaman dashboard adalah anak dari si parent/orang tua--}}

    @section('content')
<h3 style="text-align: center">
Nama : Farhatul atqiya<br>
Nim : 0110122094 <br>
Rombel : SI01 <br>
Asdos : Kak Farhan </h3>
@endsection