<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Tables</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
            <li class="breadcrumb-item active">Pesanan</li>
        </ol>
        <div class="card mb-4">
            <div class="card-header">
                <a href="<?php echo e(url('admin/pesanan/create')); ?>" class="btn btn-primary">Tambah Data</a>
            </div>
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Data Pesanan
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Nama_pemesan</th>
                            <th>No_hp</th>
                            <th>Email</th>
                            <th>Jumlah_pemesan</th>
                            <th>Deskripsi</th>
                            <th>Produk</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;
                        ?>
                        <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no); ?></td>
                                <td><?php echo e($pes->tanggal); ?></td>
                                <td><?php echo e($pes->nama_pemesan); ?></td>
                                <td><?php echo e($pes->no_hp); ?></td>
                                <td><?php echo e($pes->email); ?></td>
                                <td><?php echo e($pes->jumlah_pesanan); ?></td>
                                <td><?php echo e($pes->deskripsi); ?></td>
                                <td><?php echo e($pes->nama_produk); ?></td>
                            </tr>
                            <?php
                                $no++;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pemweb2\bocillllllll[1]\mouse\laravel\belanja\resources\views/admin/pesanan/pesanan.blade.php ENDPATH**/ ?>