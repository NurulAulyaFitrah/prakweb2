




    

    <?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
                        <h1 class="mt-4">Tables</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item active">Produk</li>
                        </ol>
                        <div class="card mb-4">
                            <div class="card-header">
                                <a href="<?php echo e(url('admin/produk/create')); ?>" class="btn btn-primary">Tambah Data</a>
                            </div>
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Data Produk
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Kode</th>
                                            <th>Nama</th>
                                            <th>Harga_jual</th>
                                            <th>Harga_beli</th>
                                            <th>Stok</th>
                                            <th>Minimal Stok</th>
                                            <th>Deskripsi</th>
                                            <th>Kategori Produk</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no = 1;
                                        ?>
                                        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no); ?></td>
                                            <td><?php echo e($prod->kode); ?></td>
                                            <td><?php echo e($prod->nama); ?></td>
                                            <td><?php echo e($prod->harga_jual); ?></td>
                                            <td><?php echo e($prod->harga_beli); ?></td>
                                            <td><?php echo e($prod->stok); ?></td>
                                            <td><?php echo e($prod->min_stok); ?></td>
                                            <td><?php echo e($prod->deskripsi); ?></td>
                                            <td><?php echo e($prod->nama_kategori); ?></td>
                                        </tr>
                                        <?php
                                            $no++
                                        ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pemweb2\laravel\belanja\resources\views/admin/produk/produk.blade.php ENDPATH**/ ?>