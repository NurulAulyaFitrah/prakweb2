<?php echo $__env->make('arsha.layout.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('arsha.layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="layoutSidenav_content">
    <main>
    <div class="container-fluid px-4">

<?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
</div>
</div>
<?php echo $__env->make('arsha.layout.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pemweb2\laravel\belanja\resources\views/arsha/layout/app.blade.php ENDPATH**/ ?>