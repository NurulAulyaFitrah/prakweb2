




    

    <?php $__env->startSection('content'); ?>
<h3 style="text-align: center">
Nama : Farhatul atqiya<br>
Nim : 0110122094 <br>
Rombel : SI01 <br>
Asdos : Kak Farhan </h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('arsha.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pemweb2\laravel\belanja\resources\views/arsha/about/about.blade.php ENDPATH**/ ?>